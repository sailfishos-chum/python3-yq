.. include:: ../README.rst

CLI usage
=========

yq
--
.. literalinclude:: cli-doc.txt

xq
--
.. literalinclude:: cli-doc-xq.txt

tomlq
-----
.. literalinclude:: cli-doc-tomlq.txt


Change log
==========

.. toctree::
   :maxdepth: 5

   changelog
