.. include:: ../README.rst

CLI usage
=========

.. literalinclude:: cli-doc.txt

Change log
==========

.. toctree::
   :maxdepth: 5

   changelog
